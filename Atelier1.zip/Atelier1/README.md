Nom-Prenom des participants:
CAI Alice
CAI Florence
Dautecourt Thomas
Laouer Nathan
Perignon Armand

Lien du dépôt Git: https://github.com/acai0/Atelier1.git

Lien du Trello: https://trello.com/invite/b/zteWUd4M/98f537f47d73330746c464c7543b12c0/atelier1

Données utiles pour tester l'application: